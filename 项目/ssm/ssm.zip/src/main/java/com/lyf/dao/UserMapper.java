package com.lyf.dao;

import org.springframework.stereotype.Repository;

//@Repository
public interface UserMapper {
}
