package com.lyf.spring;

public interface ProducerService {
  void sendMessage(String message);
}
